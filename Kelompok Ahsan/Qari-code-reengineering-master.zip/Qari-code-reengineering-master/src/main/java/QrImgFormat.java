//dibuat class java baru untuk memuat Enum untuk data img format (png)
public enum QrImgFormat {
    png
}
