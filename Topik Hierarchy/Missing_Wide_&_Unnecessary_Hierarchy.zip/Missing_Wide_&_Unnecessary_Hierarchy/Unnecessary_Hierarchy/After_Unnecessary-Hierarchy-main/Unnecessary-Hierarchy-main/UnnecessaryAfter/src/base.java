public abstract class base {
    public abstract double calculateArea();
    public abstract double calculatePerimeter();
    public abstract double calculateVolume();
    
}
